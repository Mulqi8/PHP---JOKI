<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>


    <div class="card mb-3" style="max-width: 1080px;">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="<?= base_url() ?>/assets/img/BPN.png" class="img-fluid rounded-start" style="width : 400px; ">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h4 class="card-title">Janji Temu Ukur Administrator </h4>
                    <p>Masuk sebagai </p>
                    <p class="card-text">Semangat bekerja!!</br>
                        Selamat datang di halaman Janji Temu Ukur (JiTU).</br>
                        </br>Gunakan aplikasi ini untuk kepentingan Badan Pertanahan Nasional Batam.</p></br>
                    <p class="card-text"><small class="text-muted">Tim Support</small></p>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
